#!/usr/bin/env python3
"""Time a model from Python; the numbers match ``vc4infer bench``.

    python examples/bench.py --model yolov8n.onnx --reps 3
"""
import argparse
import os

import vc4infer


def _model_imgsz(path):
    """The static H of a 4-D model input (no GPU needed)."""
    import onnx
    m = onnx.load(path)
    for vi in m.graph.input:
        dims = [d.dim_value for d in vi.type.tensor_type.shape.dim]
        if len(dims) == 4 and dims[2] > 0:
            return int(dims[2])
    return 160


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", default="yolov8n.onnx")
    ap.add_argument("--reps", type=int, default=3)
    ap.add_argument("--input", default=None, help="optional .npy / image")
    a = ap.parse_args()
    if not os.path.isfile(a.model):
        raise SystemExit("no such model: %s" % a.model)

    x = None
    if a.input:
        if a.input.lower().endswith(".npy"):
            import numpy as np
            x = np.load(a.input).astype(np.float32)
        else:
            from PIL import Image
            from vc4infer.decode import Letterbox
            x, _ = Letterbox(_model_imgsz(a.model))(
                Image.open(a.input).convert("RGB"))

    with vc4infer.Session(a.model, device="vc4") as s:
        r = s.bench(reps=a.reps, input_numpy=x)
    print("model:  %s" % r["model"])
    print("input:  %s" % "x".join(str(d) for d in r["input_shape"]))
    print("warm-up (JIT): %.1f ms" % r["warmup_ms"])
    print("runs:   %s ms" % " / ".join("%.1f" % t for t in r["runs_ms"]))
    print("%.1f ms/image (mean), %.1f ms (median), best %.1f ms"
          % (r["mean_ms"], r["median_ms"], r["min_ms"]))
    print("%.2f FPS (mean), %.2f FPS (best)"
          % (r["fps_mean"], r["fps_best"]))
    print("%d launches/image, GPU %.1f ms (%.0f%% of wall), node wall sum %.1f ms"
          % (r["launches"], r["gpu_ms"], 100.0 * r["gpu_ms"] / r["mean_ms"],
             r["wall_sum_ms"]))
    print("arena %.1f MiB, graph pool %.1f MiB, peak %.1f MiB"
          % (r["arena_mib"], r["pool_mib"], r["pool_peak_mib"]))


if __name__ == "__main__":
    main()
