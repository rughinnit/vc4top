#!/usr/bin/env python3
"""Select the vc4 device, get numpy detections, tweak post-processing.

    python examples/run_yolo.py --model yolov8n.onnx --image bus.jpg

Nothing here is vc4infer-specific in how it consumes results: ``.boxes.xyxy``,
``.boxes.conf`` and ``.boxes.cls`` are plain numpy arrays, so the usual
confidence/IoU experiments apply.
"""
import argparse

import vc4infer


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", default="yolov8n.onnx")
    ap.add_argument("--image", default="bus.jpg")
    ap.add_argument("--imgsz", type=int, default=160)
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--iou", type=float, default=0.45)
    ap.add_argument("--out", default="bus_vc4infer.jpg")
    a = ap.parse_args()

    print("vc4infer %s, devices %r" % (vc4infer.__version__,
                                       vc4infer.available_devices()))
    model = vc4infer.YOLO(a.model, device="vc4")
    print("model %s, imgsz %d" % (model.model_path, model.imgsz))

    results = model(a.image, imgsz=a.imgsz, conf=a.conf, iou=a.iou)
    print(results)
    print("orig_shape %s   speed %s"
          % (results.orig_shape,
             {k: round(v, 1) for k, v in results.speed.items()}))
    for d in results.boxes.to_dict(model.names):
        print("  %-12s %.3f  %s" % (d["class_name"], d["confidence"],
                                    ["%.1f" % v for v in d["box"]]))

    # 1) post-processing is just numpy: raise the threshold, tighten the NMS
    strict = model(a.image, imgsz=a.imgsz, conf=0.60, iou=0.30)
    print("conf 0.60 / iou 0.30 -> %d detections %s"
          % (len(strict), strict.boxes.conf.tolist()))

    # 2) replace the decode entirely (the documented hook)
    def big_boxes_only(raw, conf, iou, max_det, agnostic=False):
        dets = vc4infer.decode.decode_head(raw, conf=conf, iou=iou,
                                           max_det=max_det, agnostic=agnostic)
        area = ((dets["boxes"][:, 2] - dets["boxes"][:, 0]) *
                (dets["boxes"][:, 3] - dets["boxes"][:, 1]))
        keep = area > 0.02 * model.imgsz * model.imgsz
        return {"boxes": dets["boxes"][keep], "scores": dets["scores"][keep],
                "classes": dets["classes"][keep]}

    big = model(a.image, decode_fn=big_boxes_only)
    print("decode_fn (area > 2%% of the input) -> %d detections"
          % len(big))

    results.save(a.out)
    print("saved %s" % a.out)
    print(results.to_json())


if __name__ == "__main__":
    main()
