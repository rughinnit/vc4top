# vc4infer Python API

`vc4infer` is a normal Python package: select the `vc4` device, hand it numpy,
get numpy back.  The QPU computes the graph; the detection-head decode and NMS
are numpy code you can read and replace.

```python
import vc4infer

print(vc4infer.__version__, vc4infer.available_devices())   # 1.0.0 ['vc4']

model = vc4infer.YOLO("yolov8n.onnx", device="vc4")
r = model("bus.jpg", imgsz=160, conf=0.25, iou=0.45)
r.boxes.xyxy          # (N, 4) float32, original image pixels
r.boxes.conf          # (N,)   float32
r.boxes.cls           # (N,)   int64
r.orig_shape          # (1080, 810)
r.plot()              # BGR uint8 numpy with boxes drawn
r.to_json()           # one JSON document
```

## Install

Two pieces, on purpose:

| piece | contains | install |
|---|---|---|
| `vc4infer` .deb | `libvc4infer.so.1`, headers, CLI, kernel JIT, selftest models, and the same Python package system-wide | `sudo apt install vc4infer` |
| `vc4infer` wheel | the pure-Python package (API, CLI module, executor, ctypes binding, kernel generator) — `py3-none-any`, no compilation | `pip install vc4infer-1.0.0-py3-none-any.whl` |

The wheel is pure Python (`py3-none-any`), so it cannot carry the
architecture-specific engine library; the .deb provides it.  Installing both
is the supported layout.  In a venv:

```sh
sudo apt install vc4infer
python3 -m venv ~/venvs/vc4 && . ~/venvs/vc4/bin/activate
pip install https://rughinnit.github.io/vc4top/pip/vc4infer-1.0.0-py3-none-any.whl
# or, as an extra index:
pip install --extra-index-url https://rughinnit.github.io/vc4top/pip/simple/ vc4infer
```

Dependencies installed by pip: `numpy`, `onnx>=1.14`, `pillow`.
`vc4d` must be running (`systemctl start vc4d`); the package defaults
`VC4INFER_DAEMON=1` and the client never opens `/dev/mem`.

## API reference

### Module

| name | meaning |
|---|---|
| `vc4infer.__version__` | `"1.0.0"` |
| `vc4infer.available_devices()` | `["vc4"]` — the only device |
| `vc4infer.Session(model_path, device="vc4", imgsz=160, arena_mb=None, cache_dir=None)` | one loaded graph |
| `vc4infer.YOLO(model_path, device="vc4", imgsz=None, arena_mb=None, cache_dir=None)` | detection facade |
| `vc4infer.Results`, `vc4infer.Boxes` | result containers |
| `vc4infer.decode.decode_head`, `vc4infer.decode.nms`, `vc4infer.decode.Letterbox`, `vc4infer.decode.draw`, `vc4infer.decode.COCO80` | host post-processing |
| `vc4infer.coverage.analyse(path)` | static node coverage |
| `vc4infer.UnsupportedNode` | the model needs an unsupported node/shape |
| `vc4infer.Error`, `vc4infer.Unsupported` | engine-level errors |
| `vc4infer.default_cache_dir()` | `~/.cache/vc4infer/kcache` unless overridden |

### `Session`

| member | returns / does |
|---|---|
| `Session(...)` | loads the model, opens one engine arena, uploads the weights |
| `.run(x, profile=False)` | `{output_node_name: np.ndarray}` — raw outputs, ONNX order, fp32 |
| `.nodes()` | the coverage report dict (`total`, `supported`, `unsupported`, per-node status/reason) |
| `.bench(reps=3, input_numpy=None)` | dict: `mean_ms`, `median_ms`, `min_ms`, `fps_mean`, `fps_best`, `runs_ms`, `launches`, `gpu_ms`, `wall_sum_ms`, `arena_mib`, `pool_mib`, `pool_peak_mib` |
| `.input_name`, `.input_shape`, `.output_names`, `.output_shapes` | graph metadata |
| `.imgsz` | the model's static spatial size (the `imgsz=` hint is validated against it) |
| `.last_profile` | per-node `{name, op, wall_ms, gpu_ms, launches, flops}` after `run(profile=True)` |
| `.stats` | `{launches, gpu_ms}` of the last run |
| `.close()` | release the arena (also via `with`/`__del__`) |

`run` accepts the exact model input shape, or that shape without the batch
axis.  Values are converted to contiguous fp32; a wrong shape raises
`ValueError` naming both shapes.  Only `device="vc4"` is accepted — anything
else raises `ValueError` listing `available_devices()`.

### `YOLO`

| member | meaning |
|---|---|
| `model(source, imgsz=None, conf=0.25, iou=0.45, max_det=300, agnostic=False, decode_fn=None, save=None)` | run + decode one image, returns `Results` |
| `model.predict(...)` | alias |
| `.session` | the underlying `Session` (raw access) |
| `.names` | COCO-80 class names |
| `.imgsz` | the model's input size |

`source` may be a path, a `PIL.Image`, an HWC `uint8` array, or an already
preprocessed NCHW float array.  `imgsz=` must match the exported model; a
mismatch raises instead of silently resizing.  `save="out.jpg"` writes the
annotated image.

### `Results` / `Boxes`

| `Results` | |
|---|---|
| `.boxes.xyxy`, `.boxes.conf`, `.boxes.cls` | numpy arrays |
| `.boxes.xywh`, `.boxes.data` | derived views (`data` = x1,y1,x2,y2,conf,cls) |
| `.boxes.to_dict(names)` | list of `{class_id, class_name, confidence, box}` |
| `.orig_shape` | `(h, w)` of the input image |
| `.speed` | `{preprocess, inference, postprocess}` in ms |
| `.plot()` | BGR `uint8` numpy image with boxes (ultralytics-style) |
| `.plot_pil()` / `.plot_on(image)` | PIL RGB image |
| `.save(path)` | write the annotated image |
| `.to_dict()` / `.to_json()` | the same data as the CLI's `--json` |
| `len(results)` | number of detections |

## Where post-processing lives

Everything after `session.run()` is plain numpy in
`vc4infer/decode.py` (installed:
`/usr/lib/python3/dist-packages/vc4infer/decode.py`, or inside the venv):

```python
def decode_head(out, conf=0.25, iou=0.45, agnostic=False, max_det=300,
                class_names=None):
    """[1, 4+nc, A] or [1, A, 4+nc] -> boxes xyxy / scores / classes."""

def nms(boxes, scores, iou_thr):        # greedy, per class when called that way

class Letterbox:                        # resize + centre pad, and back
    def __call__(self, pil_image) -> (CHW float32, meta)
    @staticmethod
    def to_original(boxes, meta) -> xyxy in original pixels
```

Two supported ways to change it:

1. **Change the thresholds / NMS** — they are arguments:
   `model(img, conf=0.6, iou=0.3)`; `model(img, agnostic=True)` merges classes
   before suppression.
2. **Replace the decode** — pass `decode_fn=`.  It is called as
   `fn(raw_output, conf=..., iou=..., max_det=..., agnostic=...)` and must
   return a dict with `boxes` (N,4, model input pixels), `scores` (N,),
   `classes` (N,).  The letterbox mapping back to original pixels still
   happens afterwards.

Or skip `YOLO` entirely and post-process `session.run(x)["output0"]` yourself:
the raw head is `[1, 84, 525]` at 160x160.

## Performance

Measured on the board (stock clocks, vc4d, warm kernel cache) with
`Session.bench`:

```
Session.bench(reps=3):  mean 634.5 ms  1.58 FPS  678 launches  GPU 242.7 ms
CLI vc4infer bench:     mean 709.0-735.8 ms  1.36-1.41 FPS  678 launches
```

The Python layer adds no measurable overhead: `Session.run` is one
`Runner.run` call (one ctypes call per node inside the executor), buffers and
weight panels are kept for the lifetime of the session, and the ONNX graph is
parsed once in the constructor.  The spread between the two lines is the
board's session-to-session wall-time variance (see
[CLOCK-VARIANCE.md](CLOCK-VARIANCE.md)), not API overhead.

## Threading and lifetime

* One session at a time.  A session owns a 64 MiB arena from vc4d; a second
  concurrent `Session` cannot map another one and fails with a clear
  `vc4infer.Error`.
* `Session.run` serialises calls with a lock, so a single session can be shared
  by threads (they queue).
* `close()` (or `with`) is required to free the arena before creating the next
  session in the same process.

## Errors

| exception | when |
|---|---|
| `ValueError` | `device != "vc4"`, wrong input shape, `imgsz` mismatch, bad `source` |
| `vc4infer.UnsupportedNode` | the model needs a node/attribute/shape the engine does not implement; the message names the node and op |
| `vc4infer.Unsupported` | the engine rejected an op at runtime |
| `vc4infer.Error` | engine/vc4d failure (daemon missing, arena busy, GPU timeout) |
| `FileNotFoundError` | model path does not exist |

## Limits

Same as the CLI: fp32, batch 1, static shapes, no GPU NMS/decode, `Softmax`
with at most 16 classes, square 1x1/3x3 convs only, and 320x320 needs a 192 MiB
daemon arena (`VC4_POOL_RESERVE_MB=40 VC4INFER_ARENA_MB=189`, see
[VC4INFER.md](VC4INFER.md#320x320-the-arena-recipe)).
