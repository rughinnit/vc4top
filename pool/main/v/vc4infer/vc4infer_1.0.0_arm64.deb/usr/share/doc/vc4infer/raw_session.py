#!/usr/bin/env python3
"""Raw graph outputs: Session.run returns numpy, no post-processing.

    python examples/raw_session.py --model modelC.onnx
    python examples/raw_session.py --model yolov8n.onnx --input in.npy
"""
import argparse
import os

import numpy as np

import vc4infer


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--model", default="modelC.onnx")
    ap.add_argument("--input", default=None,
                    help=".npy matching the model input (default: rng 0)")
    ap.add_argument("--reps", type=int, default=3)
    a = ap.parse_args()

    if not os.path.isfile(a.model):
        raise SystemExit("no such model: %s" % a.model)

    with vc4infer.Session(a.model, device="vc4") as s:
        print(s)
        shape = [d if d > 0 else 1 for d in s.input_shape]
        x = (np.load(a.input).astype(np.float32) if a.input
             else np.random.default_rng(0).standard_normal(shape).astype(
                 np.float32))
        out = s.run(x)
        for name, arr in out.items():
            print("  %-24s %-18s %s  min %.4g max %.4g mean %.4g"
                  % (name, "x".join(str(d) for d in arr.shape), arr.dtype,
                     arr.min(), arr.max(), arr.mean()))

        rep = s.nodes()
        print("coverage: %d nodes, %d supported, %d unsupported"
              % (rep["total"], rep["supported"], rep["unsupported"]))

        bench = s.bench(reps=a.reps, input_numpy=x)
        print("%.1f ms/image (mean), %.2f FPS, %d launches, GPU %.1f ms"
              % (bench["mean_ms"], bench["fps_mean"], bench["launches"],
                 bench["gpu_ms"]))


if __name__ == "__main__":
    main()
