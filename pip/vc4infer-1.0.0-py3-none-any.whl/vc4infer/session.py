"""A loaded ONNX graph on the VideoCore IV QPU.

    import vc4infer
    s = vc4infer.Session("yolov8n.onnx", device="vc4")
    out = s.run(image_tensor)          # {node_name: np.ndarray}
    s.close()

The session owns one engine context and one graph pool.  ``run`` is a single
``Runner.run`` call: the Python layer does no per-node work, so the overhead
over the raw executor is one dict comprehension per frame.  Only one session
should be alive at a time: vc4d hands out one 64 MiB client arena, and a second
arena does not fit in the default daemon (use ``arena_mb`` and a bigger daemon
for 320x320, see the docs).
"""
import os
import statistics
import threading
import time

import numpy as np

from . import _runtime


class Session:
    """One ONNX graph resident on the QPUs.

    Parameters
    ----------
    model_path : str
        A fixed-shape, batch-1, fp32 ONNX file.
    device : str
        Only ``"vc4"`` is accepted; anything else raises ``ValueError``.
    imgsz : int
        Requested input size.  A model's shapes are static, so the session
        records the model's real size in ``self.imgsz``; the argument is a
        hint for the YOLO facade's letterbox.
    arena_mb : int, optional
        Arena size to ask vc4d for (default: the daemon's, 64 MiB usable).
    cache_dir : str, optional
        Kernel blob cache (default ``~/.cache/vc4infer/kcache``).
    """

    def __init__(self, model_path, device="vc4", imgsz=160, arena_mb=None,
                 cache_dir=None):
        if device != "vc4":
            raise ValueError(
                "device %r is not available; vc4infer only runs on the "
                "VideoCore IV QPU (device='vc4'). "
                "vc4infer.available_devices() -> %r"
                % (device, _runtime.available_devices()))
        self.device = "vc4"
        self.model_path = os.path.abspath(model_path)
        if not os.path.isfile(self.model_path):
            raise FileNotFoundError(self.model_path)
        self._lock = threading.Lock()
        self._closed = False
        self._eng = _runtime.open_engine(cache_dir=cache_dir, arena_mb=arena_mb)
        try:
            self._runner = _runtime.Runner(self.model_path, self._eng)
            if not self._runner.float_inputs:
                raise _runtime.UnsupportedNode(
                    "%s has no float input" % self.model_path)
            self.input_name, dims = self._runner.float_inputs[0]
            self.input_shape = tuple(dims)
            self.output_names = [o.name for o in self._runner.graph.output]
            self.output_shapes = []
            for o in self._runner.graph.output:
                tt = o.type.tensor_type
                self.output_shapes.append(
                    tuple(d.dim_value if d.HasField("dim_value") else -1
                          for d in tt.shape.dim))
        except BaseException:
            self._eng.close()
            raise
        # A model's spatial size is static; honour it over the hint.
        h = self.input_shape[2] if len(self.input_shape) == 4 else None
        self.imgsz = int(h) if h and h > 0 else int(imgsz or 160)
        self.requested_imgsz = int(imgsz) if imgsz else None
        self.last_profile = []
        self.stats = None

    # ------------------------------------------------------------------ run
    def _prepare(self, x):
        a = np.asarray(x)
        if a.dtype != np.float32:
            a = a.astype(np.float32)
        if len(self.input_shape) == 4 and a.shape == self.input_shape[1:]:
            a = a[None]
        if tuple(a.shape) != tuple(self.input_shape):
            raise ValueError(
                "input has shape %s, %s expects %s"
                % (tuple(a.shape), os.path.basename(self.model_path),
                   tuple(self.input_shape)))
        return np.ascontiguousarray(a, dtype=np.float32)

    def run(self, input_numpy, profile=False):
        """Run the graph and return ``{output_node_name: np.ndarray}``.

        The arrays are raw graph outputs in ONNX (NCHW) order -- no decoding,
        thresholding or NMS.  ``profile=True`` also stores per-node timings in
        ``self.last_profile``.
        """
        x = self._prepare(input_numpy)
        with self._lock:
            if self._closed:
                raise RuntimeError("session is closed")
            s0 = self._eng.stats
            outs = self._runner.run({self.input_name: x}, profile=profile)
            s1 = self._eng.stats
        if profile:
            self.last_profile = list(self._runner.profile)
        self.stats = {
            "launches": int(s1.launches - s0.launches),
            "gpu_ms": (s1.pack_ns - s0.pack_ns +
                       s1.kernel_ns - s0.kernel_ns) / 1e6,
        }
        return {name: np.asarray(arr)
                for name, arr in zip(self.output_names, outs)}

    # -------------------------------------------------------------- reports
    def nodes(self):
        """Static coverage report (same dict as ``vc4infer nodes --json``)."""
        from . import coverage
        return coverage.analyse(self.model_path)

    def bench(self, reps=3, input_numpy=None):
        """Time the graph: ms/image, FPS, launches, GPU vs wall.

        A warm-up run (kernel JIT) is not counted.  ``input_numpy`` defaults
        to the same deterministic random tensor the CLI uses.
        """
        if input_numpy is None:
            shape = [d if d > 0 else 1 for d in self.input_shape]
            input_numpy = np.random.default_rng(0).standard_normal(
                shape).astype(np.float32)
        x = self._prepare(input_numpy)
        with self._lock:
            if self._closed:
                raise RuntimeError("session is closed")
            t0 = time.perf_counter()
            self._runner.run({self.input_name: x}, profile=True)
            warm_ms = (time.perf_counter() - t0) * 1e3
            times = []
            for _ in range(int(reps)):
                t0 = time.perf_counter()
                self._runner.run({self.input_name: x}, profile=True)
                times.append((time.perf_counter() - t0) * 1e3)
            prof = list(self._runner.profile)
            mean = statistics.mean(times)
            return {
                "model": self.model_path,
                "input_shape": list(self.input_shape),
                "reps": int(reps),
                "warmup_ms": warm_ms,
                "runs_ms": times,
                "mean_ms": mean,
                "median_ms": statistics.median(times),
                "min_ms": min(times),
                "fps_mean": 1000.0 / mean,
                "fps_best": 1000.0 / min(times),
                "nodes": len(prof),
                "launches": int(sum(p["launches"] for p in prof)),
                "gpu_ms": float(sum(p["gpu_ms"] for p in prof)),
                "wall_sum_ms": float(sum(p["wall_ms"] for p in prof)),
                "arena_mib": self._eng.arena_bytes / 2 ** 20,
                "pool_mib": self._runner.pool.size / 2 ** 20,
                "pool_peak_mib": self._runner.pool.used_bytes / 2 ** 20,
            }

    # ------------------------------------------------------------ lifecycle
    def close(self):
        if getattr(self, "_closed", True):
            return
        self._closed = True
        self._runner = None
        if self._eng is not None:
            self._eng.close()
            self._eng = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def __repr__(self):
        return ("<vc4infer.Session %s device=vc4 input=%s outputs=%s>"
                % (os.path.basename(self.model_path),
                   "x".join(str(d) for d in self.input_shape),
                   ",".join(self.output_names)))
