"""vc4infer -- ONNX inference on the VideoCore IV QPUs.

    import vc4infer

    vc4infer.available_devices()            # ['vc4']
    s = vc4infer.Session("yolov8n.onnx")    # raw graph
    out = s.run(tensor)                     # {'output0': np.ndarray}

    model = vc4infer.YOLO("yolov8n.onnx")
    r = model("bus.jpg", imgsz=160, conf=0.25)
    r.boxes.xyxy, r.boxes.conf, r.boxes.cls
    r.plot(); r.to_json()

Every float operation of the graph runs on the VideoCore IV QPUs through
``libvc4infer`` (the library is installed system-wide by the ``vc4infer``
Debian package; the Python wheel itself is pure Python).  Unsupported nodes
raise :class:`UnsupportedNode` naming the node and the ONNX op type; there is
no CPU arithmetic fallback.  Detection-head decoding and NMS are numpy code in
:mod:`vc4infer.decode`, deliberately replaceable by the caller.

Public API
----------
Session, YOLO, Results, Boxes, available_devices(), __version__
Engine/Buf/Error/Unsupported (the ctypes binding), UnsupportedNode
decode, coverage
"""

__version__ = "1.0.0"

from ._binding import (                                        # noqa: F401
    Engine, Buf, Stats, OpInfo, Error, Unsupported, VC4_OK, ERR_UNSUPPORTED,
    OP_MATMUL, OP_CONV2D, OP_ADD, OP_MUL, OP_RELU, OP_SIGMOID, OP_SILU,
    LAYOUT_ROW_MAJOR,
)
from ._onnxrun import Runner, UnsupportedNode                   # noqa: F401
from ._runtime import available_devices, default_cache_dir      # noqa: F401
from .session import Session                                    # noqa: F401
from .yolo import YOLO, Results, Boxes                          # noqa: F401
from . import decode                                            # noqa: F401
from . import coverage                                          # noqa: F401

__all__ = [
    "__version__", "Session", "YOLO", "Results", "Boxes",
    "available_devices", "default_cache_dir", "decode", "coverage",
    "Engine", "Buf", "Stats", "OpInfo", "Error", "Unsupported",
    "Runner", "UnsupportedNode",
]
