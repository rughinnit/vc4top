"""An ultralytics-like facade over :class:`vc4infer.Session`.

    import vc4infer
    model = vc4infer.YOLO("yolov8n.onnx", device="vc4")
    r = model("bus.jpg", imgsz=160, conf=0.25, iou=0.45)
    r.boxes.xyxy, r.boxes.conf, r.boxes.cls       # numpy
    r.plot()                                      # BGR image with boxes
    r.to_json()

Decode and NMS are plain numpy in :mod:`vc4infer.decode`:
``decode_head()`` does the box/class extraction, confidence threshold and
class-aware NMS; ``nms()`` is the greedy suppression; ``Reshape`` free.
Pass ``decode_fn=`` to ``model(...)`` to replace the whole post-processing, or
call the pieces directly on ``session.run(...)["output0"]``.  The QPU computes
the graph; the head decode is host code by design.
"""
import json
import os
import time

import numpy as np

from . import decode
from .session import Session


class Boxes:
    """Detections as numpy arrays: ``xyxy`` (N,4), ``conf`` (N,), ``cls`` (N,)."""

    def __init__(self, xyxy, conf, cls):
        self.xyxy = np.asarray(xyxy, dtype=np.float32).reshape(-1, 4)
        self.conf = np.asarray(conf, dtype=np.float32).reshape(-1)
        self.cls = np.asarray(cls, dtype=np.int64).reshape(-1)

    def __len__(self):
        return int(self.xyxy.shape[0])

    @property
    def xywh(self):
        b = self.xyxy
        return np.stack([(b[:, 0] + b[:, 2]) * 0.5, (b[:, 1] + b[:, 3]) * 0.5,
                         b[:, 2] - b[:, 0], b[:, 3] - b[:, 1]], axis=1)

    @property
    def data(self):
        """(N, 6): x1, y1, x2, y2, conf, cls."""
        return np.concatenate([self.xyxy, self.conf[:, None],
                               self.cls[:, None].astype(np.float32)], axis=1)

    def to_dict(self, names=None):
        names = names or decode.COCO80
        return [{"class_id": int(self.cls[i]),
                 "class_name": decode.class_name(self.cls[i], names),
                 "confidence": float(self.conf[i]),
                 "box": [float(v) for v in self.xyxy[i]]}
                for i in range(len(self))]

    def __repr__(self):
        return "Boxes(n=%d, xyxy=%s, conf=%s, cls=%s)" % (
            len(self), self.xyxy.shape, self.conf.shape, self.cls.shape)


class Results:
    """One image's results: boxes, original shape, timings, plot/json helpers."""

    def __init__(self, boxes, orig_shape, path=None, speed=None, names=None,
                 imgsz=None, model_path=None):
        self.boxes = boxes
        self.orig_shape = tuple(int(v) for v in orig_shape)
        self.path = path
        self.speed = speed or {}
        self.names = names or decode.COCO80
        self.imgsz = imgsz
        self.model_path = model_path

    def __len__(self):
        return len(self.boxes)

    def __repr__(self):
        return ("Results(%d detections, orig_shape=%s, speed=%s)"
                % (len(self), self.orig_shape,
                   {k: round(v, 1) for k, v in self.speed.items()}))

    # ------------------------------------------------------------- rendering
    def plot_pil(self):
        """A PIL RGB copy of the input image with boxes and labels drawn."""
        from PIL import Image
        if self.path and os.path.isfile(self.path):
            img = Image.open(self.path).convert("RGB")
        else:
            raise ValueError("no source image to plot on; use plot_on(image)")
        return decode.draw(img, {"boxes": self.boxes.xyxy,
                                 "scores": self.boxes.conf,
                                 "classes": self.boxes.cls}, self.names)

    def plot_on(self, image):
        """Draw the boxes on a PIL image or an HWC numpy array."""
        from PIL import Image
        if isinstance(image, np.ndarray):
            image = Image.fromarray(np.asarray(image))
        return decode.draw(image.convert("RGB"),
                           {"boxes": self.boxes.xyxy,
                            "scores": self.boxes.conf,
                            "classes": self.boxes.cls}, self.names)

    def plot(self):
        """Ultralytics-style BGR ``uint8`` numpy image with the boxes drawn."""
        return np.asarray(self.plot_pil())[:, :, ::-1].copy()

    def save(self, path):
        self.plot_pil().save(path, quality=92)
        return path

    # ----------------------------------------------------------------- export
    def to_dict(self):
        return {
            "model": self.model_path,
            "path": self.path,
            "orig_shape": list(self.orig_shape),
            "imgsz": self.imgsz,
            "speed_ms": {k: float(v) for k, v in self.speed.items()},
            "detections": self.boxes.to_dict(self.names),
        }

    def to_json(self):
        return json.dumps(self.to_dict(), indent=1)


class YOLO:
    """YOLOv8/YOLO11 detections on the VC4 QPUs, with the ultralytics API shape.

    ``model(source)`` accepts an image path, a ``PIL.Image``, an HWC ``uint8``
    array, or an already preprocessed NCHW array.  Returns a :class:`Results`.
    """

    def __init__(self, model_path, device="vc4", imgsz=None, arena_mb=None,
                 cache_dir=None):
        if device != "vc4":
            raise ValueError(
                "device %r is not available; vc4infer only runs on the "
                "VideoCore IV QPU (device='vc4')" % (device,))
        self.session = Session(model_path, device="vc4", imgsz=imgsz or 160,
                               arena_mb=arena_mb, cache_dir=cache_dir)
        self.model_path = self.session.model_path
        self.imgsz = self.session.imgsz
        self.names = list(decode.COCO80)
        self.device = "vc4"

    # ------------------------------------------------------------------ call
    def predict(self, source, **kw):
        return self.__call__(source, **kw)

    def __call__(self, source, imgsz=None, conf=0.25, iou=0.45, max_det=300,
                 agnostic=False, decode_fn=None, save=None):
        """Run one image and decode the detection head.

        Parameters
        ----------
        imgsz : int, optional
            Must equal the model's static input size (the export that produced
            the file); a mismatch raises instead of silently resizing.
        conf, iou : float
            Confidence threshold and NMS IoU threshold.
        agnostic : bool
            Class-agnostic NMS.
        decode_fn : callable, optional
            Replacement for :func:`vc4infer.decode.decode_head`; called as
            ``decode_fn(raw_output, conf=..., iou=..., max_det=...,
            agnostic=...)`` and must return a dict with ``boxes`` (xyxy in
            model pixels), ``scores`` and ``classes``.
        save : str, optional
            Write the annotated image here.
        """
        t0 = time.perf_counter()
        if imgsz and self.session.imgsz and int(imgsz) != self.session.imgsz:
            raise ValueError(
                "model input is %dx%d but imgsz=%d was requested; the exported "
                "ONNX file has a static shape -- re-export at %d"
                % (self.session.imgsz, self.session.imgsz, int(imgsz),
                   int(imgsz)))
        img, tensor, meta, path = self._load(source)
        t1 = time.perf_counter()

        outs = self.session.run(tensor)
        t2 = time.perf_counter()
        raw = outs[self.session.output_names[0]]
        if not decode.is_detection_output(raw):
            raise ValueError(
                "model output %s is not a YOLO detection head; use "
                "vc4infer.Session for raw outputs"
                % (self.session.output_names[0],))

        fn = decode_fn or decode.decode_head
        dets = fn(raw, conf=float(conf), iou=float(iou),
                  max_det=int(max_det), agnostic=bool(agnostic))
        if meta:
            dets = dict(dets)
            dets["boxes"] = decode.Letterbox.to_original(dets["boxes"], meta)
        boxes = Boxes(dets["boxes"], dets["scores"], dets["classes"])
        t3 = time.perf_counter()

        res = Results(boxes, meta["orig_hw"] if meta else tensor.shape[2:],
                      path=path,
                      speed={"preprocess": (t1 - t0) * 1e3,
                             "inference": (t2 - t1) * 1e3,
                             "postprocess": (t3 - t2) * 1e3},
                      names=self.names, imgsz=self.session.imgsz,
                      model_path=self.model_path)
        if save:
            res.save(save)
        return res

    # ---------------------------------------------------------------- inputs
    def _load(self, source):
        from PIL import Image
        if isinstance(source, (str, bytes, os.PathLike)):
            path = os.fspath(source) if not isinstance(source, bytes) else \
                source.decode()
            img = Image.open(path).convert("RGB")
            x, meta = decode.Letterbox(self.session.imgsz)(img)
            meta["orig_hw"] = (meta["orig_h"], meta["orig_w"])
            return img, x, meta, path
        if isinstance(source, Image.Image):
            img = source.convert("RGB")
            x, meta = decode.Letterbox(self.session.imgsz)(img)
            meta["orig_hw"] = (meta["orig_h"], meta["orig_w"])
            return img, x, meta, None
        a = np.asarray(source)
        if a.ndim == 4:                      # already a batch tensor
            return None, a.astype(np.float32), None, None
        if a.ndim == 3 and a.shape[2] == 3:  # HWC image
            img = Image.fromarray(a.astype(np.uint8))
            x, meta = decode.Letterbox(self.session.imgsz)(img)
            meta["orig_hw"] = (meta["orig_h"], meta["orig_w"])
            return img, x, meta, None
        if a.ndim == 3 and a.shape[0] == 3:  # CHW floats: model pixels already
            return None, a[None].astype(np.float32), None, None
        raise ValueError("unsupported source: %r (path, PIL.Image, HWC uint8 "
                         "array, or NCHW float array)" % (type(source),))

    def close(self):
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
